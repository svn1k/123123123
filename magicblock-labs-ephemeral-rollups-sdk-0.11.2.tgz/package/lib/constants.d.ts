import { PublicKey } from "@solana/web3.js";
export declare const DELEGATION_PROGRAM_ID: PublicKey;
export declare const MAGIC_PROGRAM_ID: PublicKey;
export declare const MAGIC_CONTEXT_ID: PublicKey;
export declare const PERMISSION_PROGRAM_ID: PublicKey;
export declare const EPHEMERAL_SPL_TOKEN_PROGRAM_ID: PublicKey;
export declare const HYDRA_PROGRAM_ID: PublicKey;
export declare const TOKEN_PROGRAM_ID: PublicKey;
export declare const ASSOCIATED_TOKEN_PROGRAM_ID: PublicKey;
//# sourceMappingURL=constants.d.ts.map